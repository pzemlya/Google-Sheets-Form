const express = require("express");
const { GoogleSpreadsheet } = require("google-spreadsheet");
const fs = require('fs');

const app = express();
app.use(express.json());

// ID вашей таблицы Google Sheets
const SPREADSHEET_ID = "19IZkJRyWkrzgpJNQiqXS8CvriMl3J9fXPhAF4uQb8us";

// Инициализация клиента Google Sheets
const doc = new GoogleSpreadsheet(SPREADSHEET_ID);

// Получение данных из файла gooletable.json и тут у меня не поулчаеться сделать что бы была отправка 
const credContent = fs.readFileSync('gooletable.json');
const creds = JSON.parse(credContent);

// Устанавливаем учетные данные для аутентификации сервисного аккаунта
const { client_email, private_key } = creds;
const privateKey = private_key.replace(/\\n/g, "\n");

// Загрузка данных из формы и добавление их в Google Sheets
app.post("/addData", async (req, res) => {
    try {
        console.log("Received data:", req.body); // Добавьте эту строку

        // Разрешаем доступ к вашей таблице Google Sheets
        await doc.useServiceAccountAuth({
            client_email: req.body.client_email,
            private_key: req.body.private_key.replace(/\\n/g, "\n")
        });

        // Загружаем информацию о таблице
        await doc.loadInfo();

        // Берем первый лист
        const sheet = doc.sheetsByIndex[0];

        // Добавляем новую строку с данными из формы
        await sheet.addRow({
            "Название импорта": req.body.importName,
            "Код Таблицы 1": req.body.table1Code,
            "Диапазон 1": req.body.range1,
            "Код Таблицы 2": req.body.table2Code,
            "Диапазон 2": req.body.range2
        });

        res.json({ success: true });
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Failed to add data to Google Sheets" });
    }
});

// Указываем Express использовать файлы из папки public в качестве статических ресурсов
app.use(express.static(__dirname + "/public"));

// Обработка корневого маршрута
app.get("/", (req, res) => {
    res.sendFile(__dirname + "/public/index.html");
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
