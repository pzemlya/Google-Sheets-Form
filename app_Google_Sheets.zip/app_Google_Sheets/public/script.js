document.getElementById("googleForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const formData = {
        importName: document.getElementById("importName").value,
        table1Code: document.getElementById("table1Code").value,
        range1: document.getElementById("range1").value,
        table2Code: document.getElementById("table2Code").value,
        range2: document.getElementById("range2").value
    };

    fetch("/addData", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
        const historyList = document.getElementById("history");
        const listItem = document.createElement("li");
        listItem.textContent = `${data.importName} - ${data.table1Code} - ${data.range1} - ${data.table2Code} - ${data.range2}`;
        historyList.appendChild(listItem);
    })
    .catch(error => console.error("Error:", error));
});
